# YF Voice Car

Prototype Android voice controller for YFTech-based GAC head units.

## Reverse-engineering findings from YFMyCar.apk
The APK contains references to vendor APIs under `com.yftech.vehicle.internal.adapter`, including:
- `ICarWindow`
- `controlCarWindowAll`
- `setWindowOpenPercentFL/FR/RL/RR`
- `WindowRoofOpenOpertion`, roof open percent/state callbacks
- `setWindowRoofShadeOpenPercent`, `setWindowRoofShadeOpenState`
- `setRearviewMirrorCmd` / `setRearViewMirrorCmd`
- mirror command enum including `FOLD`

This project does **not** bundle proprietary YFTech code. `VehicleBridge` resolves the head unit's installed vehicle service at runtime via reflection.

## Arabic voice commands
Examples: `افتح النوافذ`, `سكر النوافذ`, `اطوي المرايات`, `افتح المرايات`, `افتح السقف`.

## Important
The exact service-manager class and some vendor method signatures can differ by firmware. First vehicle test should collect `logcat` and runtime class/method discovery before enabling unattended or remote control.
