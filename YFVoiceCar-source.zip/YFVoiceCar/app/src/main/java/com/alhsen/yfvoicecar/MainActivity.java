package com.alhsen.yfvoicecar;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final int REQ_SPEECH=100, REQ_AUDIO=101;
    private TextView status;
    private VehicleBridge bridge;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); setContentView(com.alhsen.yfvoicecar.R.layout.activity_main);
        status=findViewById(R.id.status); bridge=new VehicleBridge(this);
        findViewById(R.id.mic).setOnClickListener(v -> listen());
        findViewById(R.id.openWindows).setOnClickListener(v -> status.setText(bridge.allWindows(true)));
        findViewById(R.id.closeWindows).setOnClickListener(v -> status.setText(bridge.allWindows(false)));
        findViewById(R.id.foldMirrors).setOnClickListener(v -> status.setText(bridge.mirrors(true)));
        findViewById(R.id.unfoldMirrors).setOnClickListener(v -> status.setText(bridge.mirrors(false)));
    }

    private void listen(){
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){ requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ_AUDIO); return; }
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ar-SA");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT,"قل أمر السيارة");
        try { startActivityForResult(i,REQ_SPEECH); } catch(Exception e){ status.setText("خدمة التعرف الصوتي غير متاحة"); }
    }

    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(req!=REQ_SPEECH||result!=RESULT_OK||data==null)return;
        ArrayList<String> r=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
        if(r!=null&&!r.isEmpty()) execute(r.get(0));
    }

    private boolean has(String s,String... words){ for(String w:words) if(s.contains(w)) return true; return false; }
    private void execute(String raw){
        String s=raw.trim().toLowerCase(Locale.ROOT); status.setText("سمعت: "+raw);
        boolean open=has(s,"افتح","فتح","نزل","نزّل");
        boolean close=has(s,"سكر","سكّر","اغلق","أغلق","قفل","ارفع");
        if(has(s,"شباك","شبابيك","نافذة","نوافذ")){ status.setText(bridge.allWindows(open&&!close)); return; }
        if(has(s,"مراية","مرايات","مرآة")){
            boolean fold=has(s,"اطوي","طي","سكر","قفل"); status.setText(bridge.mirrors(fold)); return;
        }
        if(has(s,"سقف","فتحة")){ status.setText(bridge.roof(open&&!close)); return; }
        status.setText("الأمر غير معروف: "+raw);
    }
}
