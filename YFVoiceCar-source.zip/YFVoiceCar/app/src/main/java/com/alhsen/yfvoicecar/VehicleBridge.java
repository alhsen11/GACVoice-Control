package com.alhsen.yfvoicecar;

import android.content.Context;
import java.lang.reflect.*;
import java.util.*;

/**
 * Runtime bridge to YFTech vehicle APIs discovered in YFMyCar.apk.
 * No vendor SDK is bundled; calls are resolved on the head unit at runtime.
 */
public final class VehicleBridge {
    private final Context context;
    public VehicleBridge(Context context) { this.context = context.getApplicationContext(); }

    private Object resolveService(String... classNames) throws Exception {
        for (String name : classNames) {
            try {
                Class<?> c = Class.forName(name);
                for (Method m : c.getMethods()) {
                    if ((m.getName().equals("getInstance") || m.getName().equals("getDefault")) && Modifier.isStatic(m.getModifiers())) {
                        Class<?>[] p = m.getParameterTypes();
                        if (p.length == 0) return m.invoke(null);
                        if (p.length == 1 && Context.class.isAssignableFrom(p[0])) return m.invoke(null, context);
                    }
                }
            } catch (ClassNotFoundException ignored) {}
        }
        throw new IllegalStateException("YFTech vehicle service not found");
    }

    private Object findCarWindowService() throws Exception {
        // Candidate managers vary by firmware; we intentionally resolve dynamically.
        return resolveService(
            "com.yftech.vehicle.VehicleManager",
            "com.yftech.vehicle.CarManager",
            "com.yftech.vehicle.internal.VehicleManager"
        );
    }

    private Object invokeGetterContaining(Object target, String token) throws Exception {
        for (Method m : target.getClass().getMethods()) {
            if (m.getParameterCount() == 0 && m.getName().toLowerCase(Locale.ROOT).contains(token.toLowerCase(Locale.ROOT))) {
                Object v = m.invoke(target);
                if (v != null) return v;
            }
        }
        throw new NoSuchMethodException(token);
    }

    private boolean invokeByName(Object target, String methodName, Object... args) throws Exception {
        for (Method m : target.getClass().getMethods()) {
            if (!m.getName().equals(methodName) || m.getParameterCount() != args.length) continue;
            try { m.invoke(target, args); return true; } catch (IllegalArgumentException ignored) {}
        }
        return false;
    }

    private Object enumValue(Class<?> enumClass, String... preferred) {
        if (!enumClass.isEnum()) return null;
        for (Object e : enumClass.getEnumConstants()) {
            String n = ((Enum<?>) e).name();
            for (String p : preferred) if (n.equalsIgnoreCase(p) || n.contains(p)) return e;
        }
        return null;
    }

    public String allWindows(boolean open) {
        try {
            Object manager = findCarWindowService();
            Object window = invokeGetterContaining(manager, "window");
            // YFMyCar exposes controlCarWindowAll and per-window setWindowOpenPercentXX.
            for (Method m : window.getClass().getMethods()) {
                if (m.getName().equals("controlCarWindowAll") && m.getParameterCount() == 1) {
                    Class<?> t = m.getParameterTypes()[0];
                    Object arg = t.isEnum() ? enumValue(t, open ? new String[]{"OPEN","DOWN"} : new String[]{"CLOSE","UP"}) : (t == int.class || t == Integer.class ? (open ? 1 : 0) : null);
                    if (arg != null) { m.invoke(window, arg); return open ? "تم إرسال أمر فتح النوافذ" : "تم إرسال أمر إغلاق النوافذ"; }
                }
            }
            int pct = open ? 100 : 0;
            boolean any = false;
            for (String n : new String[]{"setWindowOpenPercentFL","setWindowOpenPercentFR","setWindowOpenPercentRL","setWindowOpenPercentRR"}) any |= invokeByName(window, n, pct);
            if (any) return open ? "تم إرسال أمر فتح النوافذ" : "تم إرسال أمر إغلاق النوافذ";
            return "واجهة النوافذ موجودة لكن توقيع الأمر يحتاج مطابقة من السيارة";
        } catch (Throwable e) { return "تعذر الوصول لخدمة النوافذ: " + e.getClass().getSimpleName(); }
    }

    public String mirrors(boolean fold) {
        try {
            Object manager = findCarWindowService();
            Object mirror;
            try { mirror = invokeGetterContaining(manager, "mirror"); } catch (Exception ex) { mirror = manager; }
            for (Method m : mirror.getClass().getMethods()) {
                if ((m.getName().equals("setRearviewMirrorCmd") || m.getName().equals("setRearViewMirrorCmd")) && m.getParameterCount() >= 1) {
                    Class<?> t = m.getParameterTypes()[m.getParameterCount()-1];
                    Object cmd = t.isEnum() ? enumValue(t, fold ? new String[]{"FOLD","CLOSE"} : new String[]{"UNFOLD","OPEN"}) : null;
                    if (cmd != null) {
                        Object[] a = new Object[m.getParameterCount()];
                        Arrays.fill(a, null); a[a.length-1] = cmd;
                        if (a.length == 1) { m.invoke(mirror, a); return fold ? "تم إرسال أمر طي المرايات" : "تم إرسال أمر فتح المرايات"; }
                    }
                }
            }
            return "واجهة المرايات موجودة لكن تحتاج مطابقة التوقيع على السيارة";
        } catch (Throwable e) { return "تعذر الوصول لخدمة المرايات: " + e.getClass().getSimpleName(); }
    }

    public String roof(boolean open) {
        try {
            Object manager = findCarWindowService();
            Object window = invokeGetterContaining(manager, "window");
            int pct = open ? 100 : 0;
            for (Method m : window.getClass().getMethods()) {
                if (m.getName().equals("setWindowRoofOpenPercent") && m.getParameterCount() == 1) {
                    m.invoke(window, pct); return open ? "تم إرسال أمر فتح السقف" : "تم إرسال أمر إغلاق السقف";
                }
            }
            return "قراءة السقف موجودة في YFMyCar؛ أمر الكتابة يحتاج تحديد اسمه النهائي";
        } catch (Throwable e) { return "تعذر الوصول لخدمة السقف: " + e.getClass().getSimpleName(); }
    }
}
